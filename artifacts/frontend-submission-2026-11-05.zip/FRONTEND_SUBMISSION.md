# Bản nộp frontend — 05/11/2026

Frontend được cập nhật trực tiếp trong `frontend/admin/`. Một ứng dụng gồm Admin Console và Windows Simulation đơn giản.

## Chạy trình diễn

```powershell
cd D:\DoAnChuyenNganh\frontend\admin
npm install
npm run dev -- --host 127.0.0.1 --port 5174
```

Mở http://127.0.0.1:5174/machines?demo=1. Thanh vàng luôn thông báo chế độ demo; nút Admin chuyển sang quản trị.

| Tài khoản | Mật khẩu | Vai trò |
| --- | --- | --- |
| admin | Demo@12345 | Quản trị |
| khoa | Demo@12345 | Nhân viên |
| an | Demo@12345 | Nhân viên |

Domain ID có thể nhập `COMPANY\khoa` hoặc `khoa`.

## Kịch bản thuyết trình

1. Chọn PC-001, đăng nhập khoa. Profile mới có Desktop/Documents trống, quota 0/10.
2. Tạo TXT, mở và sửa nội dung; thử đổi tên, sao chép, chuyển thư mục, xóa và khôi phục file vừa xóa.
3. Tạo đủ 10 file; file thứ 11 bị từ chối. Sửa nội dung không tăng số file.
4. Đăng xuất rồi đăng nhập lại khoa trên cùng máy: còn file. Đổi sang PC-002 hoặc tài khoản an: profile độc lập.
5. Đăng xuất máy, chọn Admin trên thanh demo. Xem tài sản, tài khoản, cấp phát, quyền truy cập và quota profile; Admin không có nút xem nội dung cá nhân.

TXT/CSV hỗ trợ chỉnh sửa, PDF hỗ trợ xem; Office hỗ trợ quản lý và tải xuống. Giới hạn mỗi tài liệu 8 MiB trong bản demo.

## Build để nộp

```powershell
npm test
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

Mở http://127.0.0.1:4173/machines?demo=1. Output production ở `frontend/admin/dist/`; cần phục vụ qua HTTP với SPA fallback, không mở trực tiếp `index.html` bằng file explorer.

## Giới hạn rõ ràng

- Demo lưu dữ liệu trong bộ nhớ của tab; tải lại trang đặt lại toàn bộ dữ liệu demo. Không gọi backend thật, không thay đổi DB hay file cũ.
- Đây là bằng chứng hoạt động frontend. API/profile/Agent mới chưa tích hợp end-to-end; chưa có lưu file bền vững trên Windows trong chế độ demo.
- Bỏ `demo=1` bằng nút “Kết nối API thật” để dùng API cấu hình của ứng dụng. Các API mới còn đang triển khai nên luồng mới chưa hoàn chỉnh trong chế độ thật.
- Ticket là phân hệ sau, hiện thông báo chưa triển khai; không trình bày như chức năng hoàn tất.
- Không tạo Windows user, không Active Directory, không đồng bộ file hoặc điều khiển máy từ xa.
